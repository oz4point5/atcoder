# -*- coding: utf-8 -*-

s = []
s.append(1)
s.append(2)
s.append(3)
print(s[-1])
s.pop()
print(s[-1])
s.pop()
print(s[-1])
s.pop()
